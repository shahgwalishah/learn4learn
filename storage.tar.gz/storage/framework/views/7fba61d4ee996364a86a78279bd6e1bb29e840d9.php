<footer class="footer BackColor">
    <div class="container-fluid">






















        <div class="copyright">
            &copy; <?php echo e(now()->year); ?> <?php echo e(__('made with')); ?> <i class="tim-icons icon-heart-2"></i> <?php echo e(__('by')); ?>

            <a href="https://creative-tim.com" target="_blank" id="custom"><?php echo e(__('RKiX TECH')); ?></a> &amp;

        </div>
    </div>
</footer>

<style>
    #custom{
        color: white !important;
    }
    .BackColor{
        background-color: #ffc10e;
    }
</style>
<?php /**PATH /home/mahad/Desktop/rixtexh/learn4learn/resources/views/layouts/footer.blade.php ENDPATH**/ ?>