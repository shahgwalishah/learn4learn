<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>

    <style>
        body{
            align-items: center;
            background-color: #efefef;
            margin: 0 auto;
            text-align: center;
        }
    </style>
</head>
<body>
<div style="width: 50%;
            background: #fff;
            padding: 27px;
                margin: 0 auto;
            align-items: center">
    <img src="http://learning.rkixtech.com/asset/images/logo1.png" />
    <br>
    <br>
    <br>
    <div style="    width: 100%;
    margin: 0 auto;
    text-align: left;">
        <b>Hello !</b>
        <h4>Please click the button below to verify your email address.</h4>
        <br>
    </div>
    <div style="text-align:left;
    color: #fff;
    border: 0px;
    ">
        <a  href="<?php echo e($url); ?>" style="     background: #ffc10e; color: #fff;
        border:0px;
        border-radius: 10px;
        padding: 15px;
">Verify Email Address</a>
    </div>

    <div style="    width: 100%;
    margin: 0 auto;
    text-align: left;">
        <p>
            Regards,<br><br>
            Learn4Learning
        </p>
    </div>
    <br>
    <br>
    <div>
        <p>
            © 2020 Learn4Learning. All rights reserved.
        </p>
    </div>
</div>
</body>
</html>
<?php /**PATH /home/mahad/Desktop/rixtexh/learn4learn/resources/views/mail/successRegister.blade.php ENDPATH**/ ?>