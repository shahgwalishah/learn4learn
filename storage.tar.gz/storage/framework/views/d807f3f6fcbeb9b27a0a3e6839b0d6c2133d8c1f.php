<?php echo e($slot); ?>

<?php /**PATH /home/mahad/Desktop/rixtexh/learn4learn/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>