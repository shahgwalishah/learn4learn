<footer class="footer">
    <div class="container-fluid">






















        <div class="copyright">
            &copy; <?php echo e(now()->year); ?> <?php echo e(__('made with')); ?> <i class="tim-icons icon-heart-2"></i> <?php echo e(__('by')); ?>

            <a href="https://creative-tim.com" target="_blank"><?php echo e(__('RKiX TECH')); ?></a> &amp;

        </div>
    </div>
</footer>
<?php /**PATH /home/mustafa/Desktop/rikxtech/learnforlearning/resources/views/layouts/footer.blade.php ENDPATH**/ ?>